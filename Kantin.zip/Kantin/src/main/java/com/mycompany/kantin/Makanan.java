/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kantin;

abstract class Menus<N, H>{
    public N nama;
    public H harga;
    
    abstract <N> N getNama();
    abstract <H> H getHarga();
}

public class Makanan<N, H> extends Menus{
    public Makanan(N nama, H harga){
        this.nama  = nama;
        this.harga = harga;  
    }
    
    public void setNama(N nama){
        this.nama = nama;
    }
    
    public void setHarga(H harga){
        this.harga = harga;
    }
    
    @Override
    N getNama(){
        return (N)nama;
    }
    
    @Override
    H getHarga(){
        return (H)harga;
    }
}
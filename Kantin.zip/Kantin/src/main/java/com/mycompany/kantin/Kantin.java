/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.kantin;

/**
 *
 * @author user
 */
public class Kantin {

    public static void main(String[] args) {
        Login userAdmin = new Login();
        userAdmin.setVisible(true);
        userAdmin.pack();
        userAdmin.setLocationRelativeTo(null);
        userAdmin.setDefaultCloseOperation(Login.EXIT_ON_CLOSE);
    }
}

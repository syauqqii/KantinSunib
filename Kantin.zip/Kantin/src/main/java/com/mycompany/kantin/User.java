/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kantin;

/**
 *
 * @author user
 */
public class User{
    String username, password, level;
    
    public User(String username, String password, String level){
        this.username = username;
        this.password = password;
        this.level = level;
    }
    
    void setUsername(String username){
        this.username = username;
    }
    
    void setPassword(String password){
        this.password = password;
    }
    
    String getUsername(){
        return this.username;
    }
    
    String getPassword(){
        return this.password;
    }
    
    String getLevel(){
        return this.level;
    }
}
